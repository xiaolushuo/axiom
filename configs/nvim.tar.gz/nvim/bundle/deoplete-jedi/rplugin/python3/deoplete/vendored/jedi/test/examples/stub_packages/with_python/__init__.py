from with_python import module as _module

func_without_stub = _module.func_without_stub


python_only = 1
both = ''
