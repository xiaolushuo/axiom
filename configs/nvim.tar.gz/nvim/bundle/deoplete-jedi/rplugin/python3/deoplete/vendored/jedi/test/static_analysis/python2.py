"""
Some special cases of Python 2.
"""
# python <= 2.7

# print is syntax:
print 1
print(1)

#! 6 name-error
print NOT_DEFINED
