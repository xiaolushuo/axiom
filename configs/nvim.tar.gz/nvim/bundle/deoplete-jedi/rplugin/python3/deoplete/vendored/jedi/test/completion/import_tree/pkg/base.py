class MyBase:
    def f1(self):
        pass
